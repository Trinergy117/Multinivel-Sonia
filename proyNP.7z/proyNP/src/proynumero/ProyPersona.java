/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proynumero;
import control.Controlador;

/**
 *
 * @author david
 */
public class ProyPersona {


    public static void main(String[] args) {
        Controlador objC=new Controlador();
        objC.iniciar();
    }
    
}
