/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proynumero;

import modelo.Numero;

/**
 *
 * @author david
 */
public class ProyNumero {


    public static void main(String[] args) {
        Numero objN=new Numero(3);
        System.out.println("Tabla \n"+objN.toString()+"\n"+objN.tabla());
        
    }
    
}
