/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import modelo.Persona;
import vista.Entrada;

/**
 *
 * @author david
 */
public class Controlador {
    Entrada objE;
    Persona objP;
    
    public Controlador(Entrada objE, Persona objP){
        this.objE=objE;
        this.objP=objP;
    }
    
    public Controlador(){
        this.objE=new Entrada();
        this.objP=new Persona();
    }
    
    public void iniciar(){
        Persona objP=new Persona("100100100","Pedro Perez",2000);
        objE.mostrar("Datos Persona: \n"+objP.toString()+"\nEdad: "+objP.edad());
    }

    public Entrada getObjE() {
        return objE;
    }

    public void setObjE(Entrada objE) {
        this.objE = objE;
    }

    public Persona getObjP() {
        return objP;
    }

    public void setObjP(Persona objP) {
        this.objP = objP;
    }
    
    
    
}
