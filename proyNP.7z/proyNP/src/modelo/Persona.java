/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;
import java.util.Calendar;

public class Persona {
    private String id, nom;
    private int fNac;
    public Persona (String id, String nom, int anio){
        this.id=id;
        this.nom=nom;
        this.fNac=anio;
    }
    
    public Persona(){
        this.id="";
        this.nom="";
        this.fNac=0;
    }
    
    @Override
    public String toString(){
        return "identificacion: "+id+"\nNombre:"+nom+"\nAño="+fNac;
    }
    
    public int edad(){
        Calendar fecha=Calendar.getInstance();
        return fecha.get(Calendar.YEAR)-this.fNac;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getfNac() {
        return fNac;
    }

    public void setfNac(int fNac) {
        this.fNac = fNac;
    }
    
    
    
    
}
