
package control;

import modelo.Fecha;
import modelo.Persona;
import vista.Entrada;

public class Controlador {
    Entrada objE;
    Persona objP;
    
    public Controlador(Entrada objE, Persona objP){
        this.objE=objE;
        this.objP=objP;
    }
    
    public Controlador(){
        this.objE=new Entrada();
        this.objP=new Persona();
    }
    
    public void iniciar(){
        //Persona objP=new Persona("100100100","Pedro Perez",new Fecha(6,9,2000));
        objE.mostrar("Datos Persona: \n"+objP.toString()+"\nEdad: "+objP.edad());
        do{
            Persona objPe=new Persona();
            objPe.setId(objE.leerTexto("Identificacion: "));
            objPe.setNom(objE.leerTexto("Nombre: "));
            String sFecha[]=objE.leerTexto("Fecha Nacimiento (dd/mm/aa)").split("/");
            objPe.setfNac(new Fecha(Integer.parseInt(sFecha[0]),
                                Integer.parseInt(sFecha[1]),
                                Integer.parseInt(sFecha[2])));
            objE.mostrar("Datos Persona:\n"+objPe.toString()+
                         "\nEdad: "+objPe.edad());   
        }while(objE.validar("Desea registrar otra Persona(1=Si)"));
             
    }

    public Entrada getObjE() {
        return objE;
    }

    public void setObjE(Entrada objE) {
        this.objE = objE;
    }

    public Persona getObjP() {
        return objP;
    }

    public void setObjP(Persona objP) {
        this.objP = objP;
    }
    
    
    
}
