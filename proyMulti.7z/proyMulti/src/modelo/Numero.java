
package modelo;

public class Numero {
    private int num;
    
   public Numero(int num) {
       this.num=num;
       
   }
   
   public Numero(){
       this.num=0;
   }
   
   public int getNum(){
       return num;
   }
   
   public void setNum(int num){
       this.num=num;
   }
   
   public String tabla(){
       String resp="";
       for(int i=1;i<=10;i++){
           resp+=i+" * "+num+" = "+i*num+"\n";
       }
       return resp;
   }
   
    @Override
   public String toString(){
       return "numero: " + num;
   }
   
}
