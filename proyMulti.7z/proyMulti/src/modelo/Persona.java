
package modelo;
import java.util.Calendar;

public class Persona {
    private String id, nom, tel, email;
    private Fecha fNac;
    
    public Persona (String id, String nom, Fecha anio, String email, String tel){
        this.id=id;
        this.nom=nom;
        this.fNac=anio;
        this.email=email;
        this.tel=tel;
    }
    
    public Persona(){
        this.id="";
        this.nom="";
        this.fNac=new Fecha();
        this.email="";
        this.tel="";
    }
    
    @Override
    public String toString(){
        return "identificacion: "+id+
               "\nNombre:"+nom+
               "\nAño:"+fNac+
               "\nTelefono:"+tel+
               "\nEmail:"+email;
    }
    
    public int edad(){
        Calendar fecha=Calendar.getInstance();
        return fecha.get(Calendar.YEAR)-this.fNac.getAa();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public Fecha getfNac() {
        return fNac;
    }

    public void setfNac(Fecha fNac) {
        this.fNac = fNac;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    
    
    
    
}
