
package modelo;

public class Estudiante extends Persona{
    private String cod;
    private double[] notas;

    public Estudiante(String cod, double[] notas, String id, String nom, Fecha anio, String email, String tel) {
        super(id, nom, anio, email, tel);
        this.cod = cod;
        this.notas = notas;
    }

    public Estudiante(){
        super();
        this.cod = "";
        this.notas = new double[3];
    }

    public String getCod() {
        return cod;
    }

    public void setCod(String cod) {
        this.cod = cod;
    }

    public double[] getNotas() {
        return notas;
    }

    public void setNotas(double[] notas) {
        this.notas = notas;
    }

    @Override
    public String toString() {
        return super.toString()+
                 "cod=" + cod + 
                 "notas=" + notas + '}';
    }
    
    
    
}
