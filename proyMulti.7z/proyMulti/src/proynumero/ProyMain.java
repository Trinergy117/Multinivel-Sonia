
package proynumero;
import control.Controlador;

public class ProyMain {


    public static void main(String[] args) {
        Controlador objC=new Controlador();
        objC.iniciar();
    }
    
}
